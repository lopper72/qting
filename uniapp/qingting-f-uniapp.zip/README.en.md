#Dragonfly f system uniapp version front end
####Introduction
YYC Dragonfly f film and television system is a system with multiple languages at the front end and Java / PHP at the back end. It is an app system built by the industry professional team Chengdu yiyiyiaocao Technology Co., Ltd., which is open-source, non encrypted and supports secondary development. The back end of dragonfly series system is constructed by the technical director of domestic first-line well-known IT enterprises. Dragonfly series has excellent performance, It is advertised as stable operation. It not only has the list playing function of conventional TV dramas, films and episodes, classification linkage screening, film and television comments, but also contains highlights, film review circle of friends, film review recommendation function and bullet screen function. Dragonfly f system will be constantly updated to open a new window in the field of film and television systems. Dragonfly system is gradually fully open source. If it is helpful to you, I hope to give a little star encouragement. Thank you for your support.
####Dragonfly series software architecture
vue + nuve +uniapp +flutter + java + php +laravel
node.js +springboot2.2+springmvc+druid+mybatis+mangoDB+mysql+shiro-redis+redis+activemq
This library is the dragonfly f front end, which uses Vue + NUVE + uniapp
For other versions, please pay attention to the pipe network of squirrel / Dragonfly system
[squirrel short video] https://songshu.youyacao.com/video.html ]( https://songshu.youyacao.com/video.html )
[Dragonfly system https://songshu.youyacao.com/qingting.html ]( https://songshu.youyacao.com/qingting.html )
####Installation tutorial
[Dragonfly system overall installation tutorial https://doc.youyacao.com/web/#/8? page_ id=51]( https://doc.youyacao.com/web/#/8? page_ id=51)
###Dragonfly system associated warehouse
####PHP backend
[Dragonfly server Qingting API]（ https://gitee.com/youyacao/qingting-api )
[Dragonfly background management terminal Qingting admmin]（ https://gitee.com/youyacao/qingting-admin )
####Java backend
[Dragonfly server qingtingjava-s-s] everhttps://gitee.com/youyacao/qingtingjava-s-sever ]( https://gitee.com/youyacao/qingtingjava-s-sever )
[Dragonfly background management client Qingting Java manager CL] ienthttps://gitee.com/youyacao/qingting-java-manager-client ]( https://gitee.com/youyacao/qingting-java-manager-client )
####Front end and back end
[Dragonfly V system front end https://gitee.com/youyacao/qingting-valley-flutter ]( https://gitee.com/youyacao/qingting-valley-flutter )
[Dragonfly s system front end https://gitee.com/youyacao/qingting-s-uniapp ]( https://gitee.com/youyacao/qingting-s-uniapp )
[Dragonfly T system front end https://gitee.com/youyacao/qingting-team-flutter ]( https://gitee.com/youyacao/qingting-team-flutter )
[Dragonfly Q system front end https://gitee.com/youyacao/qingting-queen-uniapp ]( https://gitee.com/youyacao/qingting-queen-uniapp )
[Dragonfly f system front end https://gitee.com/youyacao/qingting-f-uniapp ]( https://gitee.com/youyacao/qingting-f-uniapp )
####File directory description
[description of dragonfly system official catalogue] https://doc.youyacao.com/web/#/8? page_ id=649]( https://doc.youyacao.com/web/#/8? page_ id=649)
####API interface documentation
[Click to view API interface document https://doc.youyacao.com/web/#/16? page_ id=93]( https://doc.youyacao.com/web/#/16? page_ id=93)
[Click to view the Java API interface document https://doc.youyacao.com/web/#/18? page_ id=226]( https://doc.youyacao.com/web/#/18? page_ id=226)
####Purchase authorization or technical support
Genuine authorized pipe network query:
[Click to query authorization and purchase other technical support services https://zhengban.youyacao.com ]( https://zhengban.youyacao.com )
Official QQ exchange group: 929353806